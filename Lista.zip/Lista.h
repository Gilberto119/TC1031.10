#pragma once 

template<class T>
class Lista {
public:
    Lista() {
        max = 100; size =0;
    };
    void insert(T d);
    void Erase();
    T getData(int pos);
    int getSize();
    void print();

private:
    vector<T> data;
    int max;
    int size;
};
template<class T>
void Lista<T>::insert(T d) {
    if (size != max) {
        data.push_back(d);
        size++;
    }

}
template<class T>
void Lista<T>::Erase() {// Si el arreglo no esta vacio
    if (size != 0) {
        data[size];
        size--;
    }
}
template<class T>
T Lista<T>::getData(int pos) {
    if (0<= pos && pos < size) {
        return data[pos];
    }

}
template<class T>
int Lista<T>::getSize() {
    return size;
}
template<class T>
void Lista<T>::print() {
    for (size_t i = 0; i < size; i++)
    {
        cout<<"["<<i<<"]"<<" - "<< data[i]<<endl;
    }

}