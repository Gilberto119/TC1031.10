#include <iostream>
#include<vector>
#include<string>
using namespace std;
#include "Lista.h"

int main()
{
    Lista<int> line;
    line.insert(1);
    line.insert(2);
    line.insert(3);
    line.insert(4);
    line.insert(5);
    line.Erase();
    line.print();
    cout<<"The total "<<line.getSize()<<endl;
    cout<<line.getData(3)<<endl<<endl;  

    Lista<string> newWord;
    newWord.insert("Hello ");
    newWord.insert("This ");
    newWord.insert("My ");
    newWord.insert("New ");
    newWord.insert("Word ");
    newWord.insert(":) ");
    newWord.Erase();
    newWord.print();
    cout<<"The total "<<newWord.getSize()<<endl;
    cout<<newWord.getData(3)<<endl;  


}